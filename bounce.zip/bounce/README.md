# HTML5 Games

A collection of old style addictive games writen in JavaScript, HTML and CSS.


## Play

Go [play](http://tommalbran.github.io/games/) and have fun :)
